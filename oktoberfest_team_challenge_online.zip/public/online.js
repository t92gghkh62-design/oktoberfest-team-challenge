(() => {
  const API = '/api';
  let socket = null;
  let eventSource = null;
  let syncing = false;
  const deviceKey = 'wiesn-device-id-v2';
  const deviceId = localStorage.getItem(deviceKey) || (() => { const id='d_'+Math.random().toString(36).slice(2)+Date.now().toString(36); localStorage.setItem(deviceKey,id); return id; })();
  const oldRegister = window.register;
  const oldEndEvent = window.endEvent;

  async function api(path, body={}) {
    const r = await fetch(API+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    const data = await r.json().catch(()=>({ok:false,error:'Ungültige Serverantwort'}));
    if(!r.ok || data.ok===false) throw new Error(data.error||'Serverfehler');
    return data;
  }
  async function getState(){ const r=await fetch(API+'/state'); const d=await r.json(); return d.state; }
  function applyServer(st){
    if(!st) return;
    const localMe=S.me;
    S=st;
    if(localMe && S.players.some(p=>p.id===localMe)) S.me=localMe;
    localStorage.setItem(KEY,JSON.stringify({me:S.me}));
  }
  function playerById(id){ return S.players.find(p=>p.id===id); }
  function gameById(id){ return GAMES.find(g=>g.id===id); }
  function setOnlineStatus(){
    const el=document.getElementById('onlineStatus');
    if(el) el.textContent='● LIVE';
  }
  function addStatus(){
    if(document.getElementById('onlineStatus')) return;
    const d=document.createElement('div'); d.id='onlineStatus'; d.textContent='● ONLINE';
    d.style.cssText='position:fixed;right:10px;bottom:10px;z-index:9999;background:#182016;color:#b7e36b;border:1px solid #52653d;border-radius:999px;padding:6px 10px;font:700 11px system-ui;box-shadow:0 4px 18px #0005';
    document.body.appendChild(d);
  }
  async function sync(){
    try { syncing=true; const st=await getState(); const wanted=S.me; applyServer(st); if(wanted && !S.me) S.me=wanted; addStatus(); syncing=false; render(); }
    catch(e){ syncing=false; addStatus(); const el=document.getElementById('onlineStatus'); if(el){el.textContent='● OFFLINE';el.style.color='#ffb4a8'} }
  }
  function connect(){
    const url='/events?playerId='+encodeURIComponent(S.me||'');
    try {
      if(eventSource) eventSource.close();
      const es=new EventSource(url); eventSource=es;
      es.addEventListener('state',e=>{ const st=JSON.parse(e.data); const meId=S.me; applyServer(st); if(meId&&!S.me)S.me=meId; setOnlineStatus(); if(screen!=='game'&&!syncing)render(); });
      es.addEventListener('duel:incoming',e=>incomingDuel(JSON.parse(e.data)));
      es.addEventListener('duel:accepted',e=>acceptedDuel(JSON.parse(e.data)));
      es.addEventListener('duel:declined',()=>toast('Die Herausforderung wurde abgelehnt.'));
      es.onopen=()=>setOnlineStatus();
      es.onerror=()=>{const el=document.getElementById('onlineStatus');if(el){el.textContent='● OFFLINE';el.style.color='#ffb4a8'}};
    } catch(e){}
    sync();
  }
  function persistMe(){ localStorage.setItem(KEY,JSON.stringify({me:S.me})); } // SSE reconnects automatically.

  window.register = async function(){
    const n=document.getElementById('name')?.value.trim();
    if(!n) return toast('Bitte zuerst deinen Namen eingeben.');
    try {
      const d=await api('/register',{name:n,deviceId});
      S=d.state; S.me=d.player.id; persistMe();
      screen=S.opening?.[S.me] ? 'home' : 'opening';
      render();
      connect();
    } catch(e){ toast(e.message); }
  };

  window.openingTap = async function(){
    const el=document.getElementById('react');
    if(!openReady){
      if(openStart===0){openStart=Date.now();setTimeout(()=>{openReady=true;openStart=Date.now();el.className='tap go';el.textContent='PROST!'},700+Math.random()*1800)}
      else toast('Zu früh! Noch einmal.'); return;
    }
    const ms=Date.now()-openStart, n=ms<300?500:ms<550?350:200;
    try { const d=await api('/opening',{playerId:S.me,points:n}); applyServer(d.state); S.me=S.me; toast(`${ms} ms · +${n} Punkte`); setTimeout(()=>nav('home'),500); }
    catch(e){toast(e.message)}
  };

  window.opponentUI = function(){
    const valid=S.players.filter(p=>p.id!==S.me&&!already(active.id,S.me,p.id));
    screen='opponents'; document.getElementById('app').innerHTML=header()+`<div class="card"><div class="tag">${active.icon} ${active.type}</div><h2>${esc(active.name)}</h2><p class="muted">Wähle einen Gegner. Er bekommt die Anfrage auf seinem Handy und muss aktiv annehmen.</p>${valid.length?valid.map(p=>`<button class="opponent" onclick="requestDuel('${p.id}')"><div class="avatar">${p.avatar}</div><div><b>${esc(p.name)}</b><div class="muted">${esc(p.charName)} · ${p.score} P</div></div></button>`).join(''):'<div class="notice">Keine gültigen Gegner mehr für dieses Spiel.</div>'}<button class="btn alt" onclick="nav('home')">← Zurück</button></div>`;
  };
  window.requestDuel = async function(id){
    try { await api('/duels/request',{fromId:S.me,toId:id,gameId:active.id}); toast('Herausforderung gesendet. Warte auf Annahme…'); }
    catch(e){toast(e.message)}
  };
  function incomingDuel(duel){
    const g=gameById(duel.gameId), from=playerById(duel.fromId); if(!g||!from) return;
    const box=document.createElement('div'); box.id='duelPrompt'; box.style.cssText='position:fixed;inset:0;z-index:10000;background:#000b;display:flex;align-items:center;justify-content:center;padding:20px;font-family:system-ui';
    box.innerHTML=`<div style="max-width:420px;width:100%;background:#fff8e8;color:#21190f;border-radius:24px;padding:24px;box-shadow:0 20px 70px #0008;text-align:center"><div style="font-size:54px">${from.avatar}</div><h2>${esc(from.name)} fordert dich heraus!</h2><p><b>${g.icon} ${esc(g.name)}</b></p><p class="muted">Das Duell zählt erst, wenn du annimmst.</p><div class="row"><button class="btn" onclick="respondDuel('${duel.id}',true)">🍻 Annehmen</button><button class="btn danger" onclick="respondDuel('${duel.id}',false)">Ablehnen</button></div></div>`;
    document.body.appendChild(box);
  }
  window.respondDuel = async function(id,accept){
    document.getElementById('duelPrompt')?.remove();
    try { const d=await api('/duels/respond',{playerId:S.me,duelId:id,accept}); applyServer(d.state); if(accept) acceptedDuel(d.duel); }
    catch(e){toast(e.message)}
  };
  function acceptedDuel(duel){
    const g=gameById(duel.gameId); if(!g)return;
    active=g; const oppId=duel.fromId===S.me?duel.toId:duel.fromId; const opp=playerById(oppId); screen='game'; gameInit={opp,started:Date.now(),data:{}}; render(); toast('🍻 Duell angenommen – los geht’s!');
  }

  window.startGame = async function(opp){
    if(!active||!canPlay(active.id)) return toast('Dieses Spiel ist bereits 2× gespielt.');
    if(active.type==='DUELL' && opp){
      // The server has already reserved the duel when it was accepted.
      const duel=Object.values(S.duels||{}).find(d=>d.status==='accepted'&&d.gameId===active.id&&((d.fromId===S.me&&d.toId===opp.id)||(d.toId===S.me&&d.fromId===opp.id)));
      if(!duel) return toast('Bitte zuerst die Herausforderung annehmen lassen.');
      gameInit={opp,started:Date.now(),data:{}}; screen='game'; render(); return;
    }
    try { const d=await api('/game/start',{playerId:S.me,gameId:active.id}); applyServer(d.state); gameInit={opp:null,started:Date.now(),data:{}};screen='game';render(); }
    catch(e){toast(e.message)}
  };

  window.finishGame = async function(n,oppPoints=0){
    const opp=gameInit?.opp;
    try {
      const d=await api('/game/finish',{playerId:S.me,gameId:active.id,points:pts(n),opponentId:opp?.id||null,oppPoints:pts(oppPoints)});
      applyServer(d.state); toast(`+${pts(n)} Punkte!`); setTimeout(()=>nav('home'),500);
    } catch(e){toast(e.message)}
  };

  window.endEvent = async function(){
    if(!confirm('Event wirklich beenden? Danach wird die Endrangliste angezeigt.')) return;
    try { const d=await api('/event/end',{playerId:S.me}); applyServer(d.state); nav('finish'); }
    catch(e){toast(e.message)}
  };
  window.resetEvent = async function(){
    if(!confirm('Gesamten Online-Spielstand löschen und neue Runde starten?')) return;
    try { const d=await api('/event/reset'); localStorage.removeItem(KEY); S=d.state; S.me=null; screen='register'; render(); }
    catch(e){toast(e.message)}
  };

  // Keep a small local identity only; all scores and game usage come from the server.
  window.save = function(){ persistMe(); };
  addStatus();
  connect();
})();
