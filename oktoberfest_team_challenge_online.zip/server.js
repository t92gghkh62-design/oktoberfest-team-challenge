const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');

const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const PUBLIC = path.join(ROOT,'public');
const DATA = path.join(ROOT,'data','event.json');
fs.mkdirSync(path.dirname(DATA),{recursive:true});
const GAME_IDS=['quiz','memory','reaction','hits','mass','bomb','bluff','estimate','watch','potato','taboo','emoji','who','story','translate','risk','photo','boss','jackpot'];
const MAX=20;
const CHARS=[['🥨','Brezn-Boss'],['🍺','Masskrug-König'],['👒','Wiesn-Königin'],['🎺','Blasmusik-Boss'],['🍗','Hendl-Held'],['🎡','Riesenrad-Rambo'],['🍻','Biergarten-Boss'],['💃','Dirndl-Diva'],['🕺','Lederhosen-Legende'],['🎯','Wiesn-Schütze'],['😈','Wiesn-Teufel'],['🧀','Käseplatten-Kaiser'],['🐷','Haxn-Held'],['🎪','Zirkusdirektor'],['🏆','Wiesn-Champion'],['🤪','Party-Panzer'],['🍖','Schweinshaxen-Held'],['🎶','Schlager-Star'],['💥','Wiesn-Wahnsinniger'],['👑','Oktoberfest-Kaiser']];
function empty(){return {version:1,players:[],used:Object.fromEntries(GAME_IDS.map(x=>[x,0])),matches:{},opening:{},duels:{},finished:false,updatedAt:Date.now()};}
function load(){try{return JSON.parse(fs.readFileSync(DATA,'utf8'))}catch{const s=empty();save(s);return s}}
function save(s){s.updatedAt=Date.now();fs.writeFileSync(DATA,JSON.stringify(s,null,2))}
let state=load(); const clients=new Set();
const pub=p=>({id:p.id,name:p.name,avatar:p.avatar,charName:p.charName,charId:p.charId,score:p.score,played:p.played||[]});
const snapshot=()=>({...state,players:state.players.map(pub)});
function sendJSON(res,status,obj){const b=JSON.stringify(obj);res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(b)}
function broadcast(){const msg=`event: state\ndata: ${JSON.stringify(snapshot())}\n\n`;for(const c of clients){try{c.res.write(msg)}catch{clients.delete(c)}}}
function id(p='x'){return p+'_'+crypto.randomBytes(7).toString('hex')}
function player(x){return state.players.find(p=>p.id===x)}
function pair(a,b){return [a,b].sort().join('|')}
function mk(g,a,b){return `${g}|${pair(a,b)}`}
function body(req){return new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>200000)req.destroy()});req.on('end',()=>{try{resolve(s?JSON.parse(s):{})}catch(e){reject(e)}});req.on('error',reject)})}
function error(res,status,msg){sendJSON(res,status,{ok:false,error:msg})}
function serve(res,file,type){try{const b=fs.readFileSync(file);res.writeHead(200,{'Content-Type':type,'Cache-Control':'no-store'});res.end(b)}catch{res.writeHead(404);res.end('Not found')}}

async function api(req,res,pathName){
 try{
  const b=await body(req);
  if(req.method==='GET'&&pathName==='/state') return sendJSON(res,200,{ok:true,state:snapshot()});
  if(req.method==='GET'&&pathName==='/health') return sendJSON(res,200,{ok:true,players:state.players.length,finished:state.finished});
  if(req.method!=='POST') return error(res,405,'Method not allowed');
  if(pathName==='/register'){
   const name=String(b.name||'').trim().slice(0,20), deviceId=String(b.deviceId||'').slice(0,100); if(!name)return error(res,400,'Name fehlt.');
   const existing=state.players.find(p=>deviceId&&p.deviceId===deviceId); if(existing)return sendJSON(res,200,{ok:true,existing:true,player:pub(existing),state:snapshot()});
   if(state.players.length>=MAX)return error(res,409,'Maximal 20 Spieler.');
   const used=new Set(state.players.map(p=>p.charId)); let ci=CHARS.findIndex((_,i)=>!used.has(i)); if(ci<0)ci=Math.floor(Math.random()*CHARS.length);
   const p={id:id('p'),deviceId,name,avatar:CHARS[ci][0],charName:CHARS[ci][1],charId:ci,score:0,played:[]}; state.players.push(p);save(state);broadcast();return sendJSON(res,200,{ok:true,player:pub(p),state:snapshot()});
  }
  if(pathName==='/opening'){
   const p=player(b.playerId),points=Math.max(0,Math.min(500,Number(b.points)||0));if(!p)return error(res,404,'Spieler nicht gefunden.');if(state.opening[p.id])return error(res,409,'Opening bereits gespielt.');state.opening[p.id]=true;p.score+=points;p.played.push({game:'opening',points,at:Date.now()});save(state);broadcast();return sendJSON(res,200,{ok:true,state:snapshot()});
  }
  if(pathName==='/duels/request'){
   const from=player(b.fromId),to=player(b.toId),g=String(b.gameId||'');if(!from||!to||from.id===to.id)return error(res,400,'Ungültige Spieler.');if(!GAME_IDS.includes(g))return error(res,400,'Ungültiges Spiel.');if(state.finished)return error(res,409,'Event beendet.');if((state.used[g]||0)>=2)return error(res,409,'Dieses Spiel wurde bereits 2× gespielt.');if(state.matches[mk(g,from.id,to.id)])return error(res,409,'Diese Paarung hat dieses Spiel bereits gespielt.');const d={id:id('d'),gameId:g,fromId:from.id,toId:to.id,status:'pending',createdAt:Date.now()};state.duels[d.id]=d;save(state);pushPlayer(to.id,'duel:incoming',d);broadcast();return sendJSON(res,200,{ok:true,duel:d,state:snapshot()});
  }
  if(pathName==='/duels/respond'){
   const p=player(b.playerId),d=state.duels[b.duelId];if(!p||!d||d.toId!==p.id)return error(res,404,'Herausforderung nicht gefunden.');if(d.status!=='pending')return error(res,409,'Herausforderung ist nicht mehr offen.');if(!b.accept){d.status='declined';save(state);pushPlayer(d.fromId,'duel:declined',d);broadcast();return sendJSON(res,200,{ok:true,duel:d,state:snapshot()});}if((state.used[d.gameId]||0)>=2)return error(res,409,'Dieses Spiel ist inzwischen voll.');if(state.matches[mk(d.gameId,d.fromId,d.toId)])return error(res,409,'Diese Paarung wurde inzwischen gespielt.');d.status='accepted';state.used[d.gameId]=(state.used[d.gameId]||0)+1;state.matches[mk(d.gameId,d.fromId,d.toId)]=true;save(state);pushPlayer(d.fromId,'duel:accepted',d);pushPlayer(d.toId,'duel:accepted',d);broadcast();return sendJSON(res,200,{ok:true,duel:d,state:snapshot()});
  }
  if(pathName==='/game/start'){
   const p=player(b.playerId),g=String(b.gameId||'');if(!p||!GAME_IDS.includes(g))return error(res,400,'Ungültiger Start.');if(state.finished)return error(res,409,'Event beendet.');if((state.used[g]||0)>=2)return error(res,409,'Dieses Spiel wurde bereits 2× gespielt.');if(b.opponentId){if(!state.matches[mk(g,p.id,b.opponentId)])return error(res,409,'Duell wurde nicht angenommen.')}else{state.used[g]++;save(state);broadcast()}return sendJSON(res,200,{ok:true,state:snapshot()});
  }
  if(pathName==='/game/finish'){
   const p=player(b.playerId),g=String(b.gameId||''),points=Math.max(0,Math.min(2000,Number(b.points)||0)),oppPoints=Math.max(0,Math.min(2000,Number(b.oppPoints)||0));if(!p||!GAME_IDS.includes(g))return error(res,400,'Ungültiges Ergebnis.');
   if(b.opponentId){const duel=Object.values(state.duels).find(d=>d.status==='accepted'&&!d.resulted&&d.gameId===g&&((d.fromId===p.id&&d.toId===b.opponentId)||(d.toId===p.id&&d.fromId===b.opponentId)));if(!duel)return sendJSON(res,200,{ok:true,already:true,state:snapshot()});duel.resulted=true;duel.resultAt=Date.now();p.score+=points;p.played.push({game:g,points,at:Date.now()});const o=player(b.opponentId);if(o){o.score+=oppPoints;o.played.push({game:g,points:oppPoints,at:Date.now()})}}
   else {p.score+=points;p.played.push({game:g,points,at:Date.now()})}
   save(state);broadcast();return sendJSON(res,200,{ok:true,state:snapshot()});
  }
  if(pathName==='/event/end'){state.finished=true;save(state);broadcast();return sendJSON(res,200,{ok:true,state:snapshot()})}
  if(pathName==='/event/reset'){state=empty();save(state);broadcast();return sendJSON(res,200,{ok:true,state:snapshot()})}
  return error(res,404,'Unknown endpoint');
 }catch(e){return error(res,500,e.message)}
}
function pushPlayer(pid,event,data){for(const c of clients){if(c.playerId===pid){try{c.res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`)}catch{}}}}
const server=http.createServer(async(req,res)=>{
 const u=new URL(req.url,`http://${req.headers.host||'localhost'}`);
 if(u.pathname==='/events'&&req.method==='GET'){const pid=u.searchParams.get('playerId');res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive','Access-Control-Allow-Origin':'*'});res.write(`event: state\ndata: ${JSON.stringify(snapshot())}\n\n`);const c={res,playerId:pid};clients.add(c);req.on('close',()=>clients.delete(c));return;}
 if(u.pathname.startsWith('/api/')) return api(req,res,u.pathname.slice(4));
 if(u.pathname==='/'||u.pathname==='/index.html')return serve(res,path.join(PUBLIC,'index.html'),'text/html; charset=utf-8');
 if(u.pathname==='/online.js')return serve(res,path.join(PUBLIC,'online.js'),'application/javascript; charset=utf-8');
 if(u.pathname==='/socket.io/socket.io.js')return serve(res,path.join(PUBLIC,'socket.io.js'),'application/javascript; charset=utf-8');
 res.writeHead(404);res.end('Not found');
});
server.listen(PORT,()=>console.log(`Wiesn Team Challenge: http://localhost:${PORT}`));
